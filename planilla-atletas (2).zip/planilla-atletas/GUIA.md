# Planilla de atletas: guía rápida

App web gratuita que el atleta instala en su teléfono desde un link. No usa servidor ni cuentas: cada atleta guarda sus registros en su propio teléfono y te envía su semana como archivo. Tú cargas esos archivos en tu panel y de ahí salen las métricas y el reporte trimestral o semestral.

## Qué hay en la carpeta

| Archivo | Para qué |
|---|---|
| `index.html` | La app del atleta |
| `coach.html` | Tu panel: cargar semanas, ver métricas, generar reporte PDF y exportar a Excel |
| `planes/` | Un archivo `.json` por atleta con su plan. El nombre del archivo es su código |
| `planes/plantilla.json` | Ejemplo de plan para copiar |
| `planes/marcelo-x7k3.json` | Tu plan actual del Bloque 1, ya convertido |
| `manifest.webmanifest`, `sw.js`, `icons/` | Hacen que se instale como app y funcione sin conexión. No hay que tocarlos |

## 1. Publicar gratis (una vez, ~10 minutos)

**Opción A · Netlify Drop (la más simple, sin programación)**
1. Entra a `app.netlify.com/drop`.
2. Arrastra la carpeta completa `planilla-atletas`.
3. Te entrega un link tipo `https://algo.netlify.app`. Crea la cuenta gratis y **reclama el sitio** para que no se borre.
4. En la configuración del sitio puedes cambiarle el nombre (por ejemplo `planilla-marcelo.netlify.app`).

**Opción B · GitHub Pages**
1. Crea una cuenta gratis en GitHub y un repositorio nuevo.
2. Sube el contenido de la carpeta (botón «Add file › Upload files»).
3. En «Settings › Pages», elige la rama `main` y la carpeta raíz. El link queda como `https://tuusuario.github.io/repositorio/`.
4. Ojo: en el plan gratis el repositorio es público, así que cualquiera podría ver los archivos de plan. Por eso conviene la opción A.

## 2. Agregar un atleta

1. Elige un código difícil de adivinar: nombre + 4 caracteres, por ejemplo `ana-4f2k`.
2. Copia `planes/plantilla.json`, renómbralo `ana-4f2k.json` y cambia `codigo`, `atleta` y los días del plan.
   - Lo más cómodo: pídele a Claude «arma el plan de Ana en el formato de la planilla» y te entrega el archivo listo.
3. Vuelve a publicar (en Netlify, arrastra de nuevo la carpeta; en GitHub, sube el archivo).
4. Abre `coach.html` › «Link para un atleta», escribe el código y pega el mensaje en WhatsApp. El mensaje ya trae las instrucciones de instalación.

Para cambiar el plan de un atleta, editas su archivo y vuelves a publicar. Le llega la próxima vez que abra la app con internet (o con «⋯ › Actualizar mi plan»). Sus registros no se pierden.

**No pongas datos de salud en los archivos de plan**: están en internet y cualquiera con el link y el código puede verlos. Los registros (RPE, molestias, notas) nunca se suben: viven en el teléfono del atleta y en tu panel.

## 3. Lo que hace el atleta

1. Abre el link en Safari (iPhone) o Chrome (Android) y lo agrega a la pantalla de inicio.
2. **Desde ahí en adelante, lo abre siempre desde el ícono.** En iPhone, lo que se anota en Safari y lo que se anota en el ícono se guardan por separado.
3. Registra cada sesión: series, RPE, molestias y notas. Se guarda solo.
4. El domingo toca «Enviar mi semana al coach» y te manda el archivo por WhatsApp o correo.
5. Cada cierto tiempo, «⋯ › Descargar respaldo» y lo guarda en su correo o nube. Si cambia de teléfono, «Restaurar respaldo».

## 4. Tu rutina como coach

1. Junta en una carpeta los archivos `semana_….json` que te llegan.
2. Abre `coach.html` (el de tu sitio publicado) **siempre en el mismo navegador y computador**, y arrastra los archivos. Si alguien reenvía una semana, se reemplaza.
3. La tabla de atletas muestra quién está al día, cumplimiento, RPE y molestia de las últimas 4 semanas.
4. Haz clic en un atleta, elige periodo (3 meses, 6 meses, año o personalizado) y toca «Reporte en PDF». Guárdalo como PDF y envíaselo.
5. «Exportar a Excel (CSV)» saca todas las series con kg y reps, por si quieres hacer tus propios análisis.
6. **Respalda tu base cada mes** con «Respaldar base» y guarda el archivo en tu Drive. Los datos del panel viven solo en ese navegador; si borras el historial o cambias de computador, los recuperas con «Restaurar base».

## Formato del plan (resumen)

Cada día del plan es un objeto en `dias` con:

- `fecha` (AAAA-MM-DD), `dia` (texto visible), `bloque`, `semana`, `fase`
- `tipo`: `sesion`, `clase`, `carrera`, `viaje` o `descanso`
- `titulo`, `objetivo`
- `registro`: campos de texto extra al final (ej. `"WOD (rondas + reps)"`)
- `secciones`: bloques con `titulo`, `nota`, `check` (true = lista para marcar) e `items`
  - Un item con `series` y `campos` (`kg`, `reps`, `seg`) genera casillas para anotar cada serie. Esos datos alimentan las marcas y la progresión del reporte.

Opciones del plan completo:

- `zonaMolestia`: nombre de la zona que se sigue (ej. `"Lumbar"`). Si no se define, el atleta indica la zona.
- `avisoAmarillo`: mensaje que ve el atleta cuando marca molestia 4-5.
- `resumenCampos`: preguntas del resumen semanal del día de descanso.
- `ejercicios`, `focosClase`: listas sugeridas en los días de clase.
